<footer id="page-footer">
  <p>
  CSCI59P - Tim McGowen
  </p>
</footer>
</body>
</html>

