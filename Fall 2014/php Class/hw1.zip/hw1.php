// Name: Ryan Peters
// Class: CSCI 59
// Date: 8/26/14
// Professor: Tim McGowen
// Filename: hw1.php

<html>
    
    <h1>Ryan Peters</h1>
    
    <?php
	echo "My name in reverse is: ";
	echo strrev("Ryan Peters");
    ?>
    
</html>
