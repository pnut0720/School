<aside id="sidebar">
  <nav>
    <ul>
      <li>
        Menu Item
      </li>
    </ul>
    <hr/>
    <ul>
      <li>
        More Menu Items
      </li>
    </ul>
  </nav>
</aside>
