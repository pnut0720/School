#include <vector>
#include <iostream>
#include <numeric>
#include <math.h>
using namespace std;

int main()
{
	// Initialize Variables
    vector<double> myValues;
    double myNums, sum = 0, mean;
    int number = 0;

    // Prompt user for how many values they want to enter
    cout << "Please enter how many numbers you want to enter: ";
    cin >> number;
    
    cout << "\n";

    // Go through it the number of times and prompt user for values
    for (int i = 0; i < number; i++)
    {
    	cout << "Please enter value number " << i + 1 << ": ";
    	cin >> myNums;
        // Push values to the vector
    	myValues.push_back(myNums);
    }
    
    // Calculate the sum of the values
    for (int i = 0; i < myValues.size(); i++)
    {
    	sum += myValues[i];
    }
    
    // Output the values the user entered to validate that they are correct
    cout << "\nValues You Entered: ";
    
    for (int i = 0; i < myValues.size(); i++)
    {
        cout << myValues[i] << " ";
    }
    cout << "\n";

    cout << "\nSum of Numbers Entered is: " << sum << "\n";
    
    // Calculate the average/mean of the values
    mean = sum / myValues.size();
    
    double temp = 0.0, temp1 = 0.0, stdev = 0.0;
    
    for (int i = 0; i < myValues.size(); i++)
    {
        temp += (myValues[i] - mean) * (myValues[i] - mean);
    }
    temp1 = temp / (myValues.size() - 1);
    
    stdev = sqrt(temp1);
    
    cout << "\nSample Standard Deviation: " << stdev << "\n";
}
